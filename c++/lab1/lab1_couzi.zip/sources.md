# Sources

All websites visited during lab realization.

 - [StackOverflow](https://stackoverflow.com)
 - [W3 Schools](https://w3schools.com)
 - [ChatGPT](https://chat.openai.com)
 - [GitHub](https://github.com)