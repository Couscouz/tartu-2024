# Sources

All websites visited during the lab2 realization.

 - [StackOverflow](https://stackoverflow.com)
 - [GeeksforGeeks](https://www.geeksforgeeks.org)
 - [ChatGPT](https://chat.openai.com)
 - [GitHub](https://github.com)